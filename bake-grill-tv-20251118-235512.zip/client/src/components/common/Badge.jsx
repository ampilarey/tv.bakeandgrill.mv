export default function Badge({ children, color = 'default', size = 'md', className = '' }) {
  const colors = {
    default: 'bg-tv-bgSoft text-tv-textSecondary border border-tv-borderSubtle',
    primary: 'bg-tv-accent/20 text-tv-accent border border-tv-accent/40',
    success: 'bg-green-500/20 text-green-700 border border-green-500/40',
    danger: 'bg-red-500/20 text-red-700 border border-red-500/40',
    warning: 'bg-tv-warning/20 text-tv-gold border border-tv-warning/40',
    info: 'bg-blue-500/20 text-blue-700 border border-blue-500/40'
  };
  
  const sizes = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-3 py-1 text-sm',
    lg: 'px-4 py-1.5 text-base'
  };
  
  return (
    <span className={`inline-flex items-center rounded-full font-semibold ${colors[color]} ${sizes[size]} ${className}`}>
      {children}
    </span>
  );
}

