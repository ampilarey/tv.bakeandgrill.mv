-- MySQL dump 10.13  Distrib 9.4.0, for macos14.7 (x86_64)
--
-- Host: localhost    Database: bakegrill_tv
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_settings` (
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
INSERT INTO `app_settings` VALUES ('app_name','Bake and Grill TV','Application display name','2025-11-09 18:07:34'),('enable_registration','false','Allow new user signups (always false for cafe)','2025-11-09 18:07:34'),('max_playlists_per_user','10','Maximum playlists per user','2025-11-09 18:07:34'),('pwa_icon_path','/pwa-512x512.png','Path to custom PWA icon','2025-11-09 18:07:34'),('session_timeout_days','7','JWT token expiry (days)','2025-11-09 18:07:34');
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `display_commands`
--

DROP TABLE IF EXISTS `display_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `display_commands` (
  `id` int NOT NULL AUTO_INCREMENT,
  `display_id` int NOT NULL,
  `command_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `command_data` text COLLATE utf8mb4_unicode_ci,
  `is_executed` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `executed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_commands_display` (`display_id`,`is_executed`),
  CONSTRAINT `display_commands_ibfk_1` FOREIGN KEY (`display_id`) REFERENCES `displays` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `display_commands`
--

LOCK TABLES `display_commands` WRITE;
/*!40000 ALTER TABLE `display_commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `display_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `display_schedules`
--

DROP TABLE IF EXISTS `display_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `display_schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `display_id` int NOT NULL,
  `channel_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_of_week` int DEFAULT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_schedules_display` (`display_id`),
  KEY `idx_schedules_time` (`day_of_week`,`start_time`),
  CONSTRAINT `display_schedules_ibfk_1` FOREIGN KEY (`display_id`) REFERENCES `displays` (`id`) ON DELETE CASCADE,
  CONSTRAINT `display_schedules_chk_1` CHECK ((`day_of_week` between 0 and 6))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `display_schedules`
--

LOCK TABLES `display_schedules` WRITE;
/*!40000 ALTER TABLE `display_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `display_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `displays`
--

DROP TABLE IF EXISTS `displays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `displays` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `playlist_id` int DEFAULT NULL,
  `current_channel_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_pin` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_heartbeat` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `auto_play` tinyint(1) DEFAULT '1',
  `schedule_enabled` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `playlist_id` (`playlist_id`),
  KEY `idx_displays_token` (`token`),
  KEY `idx_displays_active` (`is_active`),
  KEY `idx_displays_location_pin` (`location_pin`),
  KEY `idx_displays_last_ip` (`last_ip`),
  CONSTRAINT `displays_ibfk_1` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `displays`
--

LOCK TABLES `displays` WRITE;
/*!40000 ALTER TABLE `displays` DISABLE KEYS */;
INSERT INTO `displays` VALUES (6,'1',NULL,1,'73c1dd7471a1cc717234b136c1a7b08e','0c802424b83f066e071dada29608839168a7b58241be9635efc84f111405ec51','6016',NULL,'2025-11-12 07:45:12',1,1,0,'2025-11-12 07:30:44','2025-11-12 07:45:12',1,NULL);
/*!40000 ALTER TABLE `displays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `playlist_id` int NOT NULL,
  `channel_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_favorite` (`user_id`,`playlist_id`,`channel_id`),
  KEY `idx_favorites_user` (`user_id`),
  KEY `idx_favorites_playlist` (`playlist_id`),
  CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
INSERT INTO `favorites` VALUES (1,1,1,'0956302ae5141a4e749da933193c66d4','DHAARIS TV','2025-11-12 06:16:48'),(2,1,1,'ebf48b7054daf6552cb6ac77808c7788','MMTV','2025-11-16 04:41:50');
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `read` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`,`read`,`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlists`
--

DROP TABLE IF EXISTS `playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `playlists` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `m3u_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_fetched` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_playlists_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlists`
--

LOCK TABLES `playlists` WRITE;
/*!40000 ALTER TABLE `playlists` DISABLE KEYS */;
INSERT INTO `playlists` VALUES (1,'tv','https://haa.ovh/tv.m3u','',1,'2025-11-09 18:14:29','2025-11-16 13:51:09','2025-11-16 13:51:09');
/*!40000 ALTER TABLE `playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_assigned_playlists`
--

DROP TABLE IF EXISTS `user_assigned_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_assigned_playlists` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `playlist_id` int NOT NULL,
  `assigned_by` int NOT NULL,
  `can_edit` tinyint(1) DEFAULT '0',
  `can_delete` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_assignment` (`user_id`,`playlist_id`),
  KEY `assigned_by` (`assigned_by`),
  KEY `idx_assigned_user` (`user_id`),
  KEY `idx_assigned_playlist` (`playlist_id`),
  CONSTRAINT `user_assigned_playlists_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_assigned_playlists_ibfk_2` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_assigned_playlists_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_assigned_playlists`
--

LOCK TABLES `user_assigned_playlists` WRITE;
/*!40000 ALTER TABLE `user_assigned_playlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_assigned_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `can_add_playlists` tinyint(1) DEFAULT '0',
  `can_edit_own_playlists` tinyint(1) DEFAULT '0',
  `can_delete_own_playlists` tinyint(1) DEFAULT '0',
  `can_manage_displays` tinyint(1) DEFAULT '0',
  `can_control_displays` tinyint(1) DEFAULT '0',
  `can_create_users` tinyint(1) DEFAULT '0',
  `can_view_analytics` tinyint(1) DEFAULT '0',
  `can_manage_schedules` tinyint(1) DEFAULT '0',
  `max_playlists` int DEFAULT '-1',
  `max_displays` int DEFAULT '-1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_permission` (`user_id`),
  KEY `idx_permissions_user` (`user_id`),
  CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'staff',
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_role` (`role`),
  CONSTRAINT `users_chk_1` CHECK ((`role` in (_utf8mb4'admin',_utf8mb4'staff')))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@bakegrill.com','$2b$10$YjhoEoiTJ2fe1jeCgXdsp.Rf6FCTdV//sGloeu8KU6T8FqDHcII1S','admin','Admin','User',1,'2025-11-09 18:07:34','2025-11-16 14:26:16','2025-11-16 14:26:16');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watch_history`
--

DROP TABLE IF EXISTS `watch_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `watch_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `playlist_id` int NOT NULL,
  `channel_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watched_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `duration_seconds` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `playlist_id` (`playlist_id`),
  KEY `idx_history_user` (`user_id`),
  KEY `idx_history_watched_at` (`watched_at`),
  KEY `idx_history_channel` (`channel_id`),
  CONSTRAINT `watch_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `watch_history_ibfk_2` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watch_history`
--

LOCK TABLES `watch_history` WRITE;
/*!40000 ALTER TABLE `watch_history` DISABLE KEYS */;
INSERT INTO `watch_history` VALUES (1,1,1,'70096be1dce787c0add8c163e646139b','','2025-11-09 18:14:37',14392),(2,1,1,'234bd09ff77e8668ea927fb783f80ff4','','2025-11-09 18:15:04',0),(3,1,1,'04b60f93bbe51eaa4be18eb22ffcc545','','2025-11-09 18:15:38',0),(4,1,1,'6ac4d5577b9f7865ef7425ef36484578','','2025-11-09 18:16:24',0),(5,1,1,'70096be1dce787c0add8c163e646139b','','2025-11-09 18:16:32',14392),(6,1,1,'ab23b8cbab787cd475cbd5cb2b5c23e4','','2025-11-09 18:16:40',0),(7,1,1,'3ec1eb8be8c69930921f2ccdfb47832c','','2025-11-09 18:18:19',645),(8,1,1,'207ad01c18772c71ea690f23703df108','','2025-11-09 18:18:31',1077),(9,1,1,'70096be1dce787c0add8c163e646139b','','2025-11-09 18:29:31',14392),(10,1,1,'b7419cf91b316108d16f9ceec00f6b09','.NY.us\" tvg-name=\"\" tvg-logo=\"https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/united-states/us-local/fox-5-wnyw-us.png\" group-title=\"USA\",FOX (WNYW)','2025-11-09 18:31:06',0),(11,1,1,'8f04cc7b6dd2636dd02b52fc80cf0125','BBC 1','2025-11-09 18:31:17',11),(12,1,1,'b7419cf91b316108d16f9ceec00f6b09','.NY.us\" tvg-name=\"\" tvg-logo=\"https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/united-states/us-local/fox-5-wnyw-us.png\" group-title=\"USA\",FOX (WNYW)','2025-11-09 18:34:07',0),(13,1,1,'130382fec882518f875a9dfa1a4b88a4','&picture','2025-11-09 18:36:38',0),(14,1,1,'f6a6ce93debe280b1ece11305d4bb100','A&E HD','2025-11-09 18:37:08',0),(15,1,1,'8f04cc7b6dd2636dd02b52fc80cf0125','BBC 1','2025-11-09 18:37:21',13),(16,1,1,'130382fec882518f875a9dfa1a4b88a4','&picture','2025-11-09 18:37:39',0),(17,1,1,'56b11b47f85ad58c8e1caf35924e6a70','Astro Sports UHD','2025-11-09 18:38:40',0),(18,1,1,'130382fec882518f875a9dfa1a4b88a4','&picture','2025-11-09 18:38:54',0),(19,1,1,'130382fec882518f875a9dfa1a4b88a4','&picture','2025-11-09 18:39:56',0),(20,1,1,'8f04cc7b6dd2636dd02b52fc80cf0125','BBC 1','2025-11-09 18:40:02',12),(21,1,1,'130382fec882518f875a9dfa1a4b88a4','&picture','2025-11-09 18:41:09',0),(22,1,1,'130382fec882518f875a9dfa1a4b88a4','&picture','2025-11-09 18:42:38',0),(23,1,1,'11320ed5b8ffe6b1ba9840e542a219fd','&picture','2025-11-09 18:44:39',0),(24,1,1,'116d29303d98283c7f6996199ba84cf8','CHANNEL 13','2025-11-09 18:44:51',0),(25,1,1,'0956302ae5141a4e749da933193c66d4','DHAARIS TV','2025-11-09 18:45:04',8),(26,1,1,'11320ed5b8ffe6b1ba9840e542a219fd','&picture','2025-11-09 18:45:57',0),(27,1,1,'11320ed5b8ffe6b1ba9840e542a219fd','&picture','2025-11-09 18:47:19',0),(28,1,1,'d0118cdc7e26a2bca085423d522ea3f0','&tv','2025-11-09 18:47:26',0),(29,1,1,'b7f0e6a846cde4c1785bc172a87416f3','A Sports HD PK','2025-11-09 18:47:40',0),(30,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 09:26:15',0),(31,1,1,'0956302ae5141a4e749da933193c66d4','DHAARIS TV','2025-11-11 09:26:23',0),(32,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 09:27:28',0),(33,1,1,'0956302ae5141a4e749da933193c66d4','DHAARIS TV','2025-11-11 09:27:36',0),(34,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 17:52:58',0),(35,1,1,'0956302ae5141a4e749da933193c66d4','DHAARIS TV','2025-11-11 17:53:10',6),(36,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 17:53:32',0),(37,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 17:56:31',0),(38,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 17:56:44',0),(39,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 17:59:43',0),(40,1,1,'0956302ae5141a4e749da933193c66d4','DHAARIS TV','2025-11-11 18:00:25',6),(41,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 18:00:47',0),(42,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 18:02:40',0),(43,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 18:02:51',0),(44,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 18:03:41',0),(45,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 18:05:51',0),(46,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 18:05:59',0),(47,1,1,'d69d203e0b60d21ae5b90aa5a7aad1ce','&Flix HD','2025-11-11 18:06:12',0),(48,1,1,'1a1d3201883898985bbc81a27bcf9a4e','MUNNAARU TV','2025-11-11 18:06:42',0),(49,1,1,'a51356b458eae38b84be29a0777df56b','SSTV','2025-11-11 18:07:19',1077),(50,1,1,'73c1dd7471a1cc717234b136c1a7b08e','TVM','2025-11-11 18:08:18',14392),(51,1,1,'d39531bb88efb29b4c9859d00f8793bd','SANGU TV','2025-11-11 18:08:37',0),(52,1,1,'73c1dd7471a1cc717234b136c1a7b08e','TVM','2025-11-12 04:06:48',0),(53,1,1,'1a1d3201883898985bbc81a27bcf9a4e','MUNNAARU TV','2025-11-12 04:07:06',0),(54,1,1,'0956302ae5141a4e749da933193c66d4','DHAARIS TV','2025-11-12 04:07:20',0),(55,1,1,'ebf48b7054daf6552cb6ac77808c7788','MMTV','2025-11-12 04:07:29',84),(56,1,1,'0956302ae5141a4e749da933193c66d4','DHAARIS TV','2025-11-12 05:01:39',0),(57,1,1,'73c1dd7471a1cc717234b136c1a7b08e','TVM','2025-11-12 05:02:00',0),(58,1,1,'73c1dd7471a1cc717234b136c1a7b08e','TVM','2025-11-12 05:03:10',0),(59,1,1,'73c1dd7471a1cc717234b136c1a7b08e','TVM','2025-11-12 06:14:14',0),(60,1,1,'0956302ae5141a4e749da933193c66d4','DHAARIS TV','2025-11-12 06:14:46',6),(61,1,1,'ebf48b7054daf6552cb6ac77808c7788','MMTV','2025-11-12 06:15:34',0),(62,1,1,'0956302ae5141a4e749da933193c66d4','DHAARIS TV','2025-11-12 06:16:51',6);
/*!40000 ALTER TABLE `watch_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-16 23:05:15
