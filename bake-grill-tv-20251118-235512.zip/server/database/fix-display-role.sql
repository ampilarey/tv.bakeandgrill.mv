-- Quick fix for display role constraint
-- Run this manually if migration doesn't work automatically

-- Drop the constraint (will fail if it doesn't exist, that's ok)
ALTER TABLE users DROP CHECK users_chk_1;

-- Add new constraint with 'display' role
ALTER TABLE users 
ADD CONSTRAINT users_chk_1 
CHECK (role IN ('admin', 'staff', 'user', 'display'));

